<?php echo doctype('html5'); ?>
<html lang="eng">
<head>
	<title>Blogging System</title>
	<?php echo meta('viewport','width=device-width'), meta('Content-type', 'text/html; charset=utf-8', 'equiv'); 
    ?>
    <?php echo link_tag('styles/css/bootstrap.min.css'); 
    echo link_tag('styles/css/login.css');
    ?>
</head>
<body>
	<div class="container">
		<div class="jumbotron">
			<h2 class="text-center"><u>Codeigniter Blogging System</u></h2>
		</div>
	