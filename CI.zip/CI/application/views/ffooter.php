	</div>
<script src="<?php echo base_url('styles/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('styles/js/bootstrap.min.js'); ?>"></script>
</body>
</html>